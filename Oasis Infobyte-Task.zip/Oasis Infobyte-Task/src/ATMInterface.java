import java.util.*;

class Account {
    private String userId;
    private String pin;
    private double balance;
    private ArrayList<String> transactionHistory;

    public Account(String userId, String pin, double balance) {
        this.userId = userId;
        this.pin = pin;
        this.balance = balance;
        this.transactionHistory = new ArrayList<>();
        this.transactionHistory.add("Account created with initial balance: $" + balance);
    }

    public String getUserId() {
        return userId;
    }

    public String getPin() {
        return pin;
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            transactionHistory.add("Deposited: $" + amount + ", New Balance: $" + balance);
            System.out.println("Successfully deposited $" + amount);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    public boolean withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            transactionHistory.add("Withdrew: $" + amount + ", Remaining Balance: $" + balance);
            System.out.println("Successfully withdrew $" + amount);
            return true;
        } else {
            System.out.println("Insufficient balance or invalid amount.");
            return false;
        }
    }

    public boolean transfer(Account recipient, double amount) {
        if (withdraw(amount)) {
            recipient.deposit(amount);
            transactionHistory.add("Transferred: $" + amount + " to " + recipient.getUserId());
            System.out.println("Successfully transferred $" + amount + " to " + recipient.getUserId());
            return true;
        }
        return false;
    }

    public void showTransactionHistory() {
        System.out.println("\nTransaction History:");
        for (String transaction : transactionHistory) {
            System.out.println(transaction);
        }
    }
}

public class ATMInterface {
    private static Scanner sc = new Scanner(System.in);
    private static Map<String, Account> accounts = new HashMap<>();

    public static void main(String[] args) {

        accounts.put("user1", new Account("user1", "101", 6379));
        accounts.put("user2", new Account("user2", "102", 4576));

        System.out.println("Welcome to the ATM System");


        Account currentUser = login();
        if (currentUser != null) {

            boolean quit = false;
            while (!quit) {
                System.out.println("\nATM Menu:");
                System.out.println("1. Transaction History");
                System.out.println("2. Withdraw");
                System.out.println("3. Deposit");
                System.out.println("4. Transfer");
                System.out.println("5. Quit");
                System.out.print("Choose an option: ");
                int choice = sc.nextInt();
                sc.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        currentUser.showTransactionHistory();
                        break;
                    case 2:
                        withdraw(currentUser);
                        break;
                    case 3:
                        deposit(currentUser);
                        break;
                    case 4:
                        transfer(currentUser);
                        break;
                    case 5:
                        quit = true;
                        System.out.println("Thank you for using the ATM. Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            }
        } else {
            System.out.println("Invalid login credentials. Exiting...");
        }
    }

    private static Account login() {
        System.out.print("Enter User ID: ");
        String userId = sc.nextLine();
        System.out.print("Enter PIN: ");
        String pin = sc.nextLine();

        if (accounts.containsKey(userId)) {
            Account account = accounts.get(userId);
            if (account.getPin().equals(pin)) {
                System.out.println("Login successful!");
                return account;
            } else {
                System.out.println("Incorrect PIN.");
            }
        } else {
            System.out.println("Account not found.");
        }
        return null;
    }


    private static void withdraw(Account account) {
        System.out.print("Enter amount to withdraw: $");
        double amount = sc.nextDouble();
        account.withdraw(amount);
    }


    private static void deposit(Account account) {
        System.out.print("Enter amount to deposit: $");
        double amount = sc.nextDouble();
        account.deposit(amount);
    }


    private static void transfer(Account senderAccount) {
        System.out.print("Enter recipient User ID: ");
        String recipientId = sc.nextLine();

        if (accounts.containsKey(recipientId)) {
            Account recipientAccount = accounts.get(recipientId);
            System.out.print("Enter amount to transfer: $");
            double amount = sc.nextDouble();

            senderAccount.transfer(recipientAccount, amount);
        } else {
            System.out.println("Recipient account not found.");
        }
    }
}
