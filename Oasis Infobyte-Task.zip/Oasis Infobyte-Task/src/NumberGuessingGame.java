import java.util.Random;
import java.util.Scanner;

public class NumberGuessingGame {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("\nWelcome to the Number Guessing Game !! \n");

        boolean playAgain = true;
        int round = 1;
        int totalScore = 0;

        while (playAgain) {
            System.out.println("\n|-- Round: " + round + " --|");
            int score = playGame();
            totalScore += score;

            System.out.println("Your score for this round: " + score);
            System.out.println("Total score: " + totalScore);

            System.out.print("Do you want to play another round? (yes/no): ");
            String response = sc.nextLine();

            if (!response.equalsIgnoreCase("yes")) {
                playAgain = false;
            }
            round++;
        }

        System.out.println("\nThank you for playing! Your final score is: " + totalScore);
    }


    public static int playGame() {
        Random random = new Random();
        int randomNumber = random.nextInt(100) + 1;
        int attemptsAllowed = 10;
        int attempts = 0;
        int score = 100;

        System.out.println("I'm thinking of a number between 1 and 100.");
        System.out.println("You have " + attemptsAllowed + " attempts to guess it!");

        while (attempts < attemptsAllowed) {
            System.out.print("Enter your guess: ");
            int guess = sc.nextInt();
            sc.nextLine();

            attempts++;

            if (guess == randomNumber) {
                System.out.println("Congratulations! You guessed the correct number in " + attempts + " attempts.");
                score -= (attempts - 1) * 10;
                return score;
            } else if (guess < randomNumber) {
                System.out.println("Your guess is too low.");
            } else {
                System.out.println("Your guess is too high.");
            }

            System.out.println("Attempts remaining: " + (attemptsAllowed - attempts));
        }

        System.out.println("Sorry, you've run out of attempts. The correct number was: " + randomNumber);
        return 0;
    }
}
