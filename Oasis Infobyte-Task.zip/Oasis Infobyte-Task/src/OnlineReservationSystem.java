import java.util.*;

class Train {
    int trainNumber;
    String trainName;
    String classType;
    String from;
    String to;
    String journeyDate;
    String passengerName;
    String pnr;

    public Train(int trainNumber, String trainName, String classType, String from, String to, String journeyDate, String passengerName, String pnr) {
        this.trainNumber = trainNumber;
        this.trainName = trainName;
        this.classType = classType;
        this.from = from;
        this.to = to;
        this.journeyDate = journeyDate;
        this.passengerName = passengerName;
        this.pnr = pnr;
    }

    @Override
    public String toString() {
        return "PNR: " + pnr + ", Train No: " + trainNumber + ", Train Name: " + trainName + ", Class: " + classType +
                ", From: " + from + ", To: " + to + ", Date: " + journeyDate + ", Passenger: " + passengerName;
    }
}

class User {
    String userId;
    String password;

    public User(String userId, String password) {
        this.userId = userId;
        this.password = password;
    }
}

public class OnlineReservationSystem {

    static List<User> users = new ArrayList<>();
    static List<Train> reservations = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);

    static {
        users.add(new User("admin", "admin@123"));
    }

    public static void main(String[] args) {
        if (login()) {
            while (true) {
                System.out.println("\n1. Make a Reservation !");
                System.out.println("\n2. Cancel a Reservation !");
                System.out.println("\n3. Exit !\n");
                System.out.print("Choose an option: ");
                int choice = sc.nextInt();
                sc.nextLine();
                switch (choice) {
                    case 1:
                        makeReservation();
                        break;
                    case 2:
                        cancelReservation();
                        break;
                    case 3:
                        System.out.println("Exiting system.");
                        return;
                    default:
                        System.out.println("Invalid choice. Try again.");
                }
            }
        } else {
            System.out.println("Invalid login. Exiting system.");
        }
    }

    public static boolean login() {
        System.out.print("Enter User ID: ");
        String userId = sc.nextLine();
        System.out.print("Enter Password: ");
        String password = sc.nextLine();
        for (User user : users) {
            if (user.userId.equals(userId) && user.password.equals(password)) {
                System.out.println("Login successful!");
                return true;
            }
        }
        return false;
    }

    public static void makeReservation() {
        System.out.println("|----------------------------|\n" +
                           "|----- Reservation Form -----|\n" +
                           "|----------------------------|\n");
        System.out.print("Enter Passenger Name: ");
        String passengerName = sc.nextLine();

        System.out.print("Enter Train Number: ");
        int trainNumber = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Train Name: ");
        String trainName = sc.nextLine();

        System.out.print("Enter Class Type (Sleeper/AC/General): ");
        String classType = sc.nextLine();

        System.out.print("Enter From (Place): ");
        String from = sc.nextLine();

        System.out.print("Enter To (Destination): ");
        String to = sc.nextLine();

        System.out.print("Enter Journey Date (DD/MM/YYYY): ");
        String journeyDate = sc.nextLine();

        String pnr = generatePNR();
        Train reservation = new Train(trainNumber, trainName, classType, from, to, journeyDate, passengerName, pnr);
        reservations.add(reservation);

        System.out.println("Reservation successful ! Your PNR is: " + pnr);
    }

    public static void cancelReservation() {
        System.out.print("Enter PNR Number: ");
        String pnr = sc.nextLine();
        Train reservationToCancel = null;
        for (Train reservation : reservations) {
            if (reservation.pnr.equals(pnr)) {
                reservationToCancel = reservation;
                break;
            }
        }

        if (reservationToCancel != null) {
            System.out.println("Reservation found: ");
            System.out.println(reservationToCancel);
            System.out.print("Are you sure you want to cancel this reservation? (yes/no): ");
            String confirmation = sc.nextLine();
            if (confirmation.equalsIgnoreCase("yes")) {
                reservations.remove(reservationToCancel);
                System.out.println("Reservation cancelled.");
            } else {
                System.out.println("Cancellation aborted.");
            }
        } else {
            System.out.println("No reservation found with the given PNR.");
        }
    }

    public static String generatePNR() {
        return "PNR" + new Random().nextInt(999999);
    }
}
